<?php

$servername = "localhost";  
$username = "root";  
$password = "";  
$conn = mysqli_connect ($servername , $username , $password) or die("unable to connect to host");  
$sql = mysqli_select_db ('web',$conn) or die("unable to connect to database"); 

printf("There are %u million bicycles in %s.",$sql);

//$name = $_POST['name'];
//$visitor_email = $_POST['email'];
//$subject = $_POST['subject'];
//$message = $_POST['message'];



?>